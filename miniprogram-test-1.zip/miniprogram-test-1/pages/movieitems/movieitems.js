// pages/movieitems/movieitems.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    value: 5,
    isOpen: false,
    isFold: false, // 是否显示'展开' 默认不显示显示
    casts:"",
    directors:""
  },
  open() {
    this.setData({
      isOpen: this.data.isOpen ? false : true
    })
  },
 

  onChange(event) {
    this.setData({
      value: event.detail
    });
  },
  xiangkan: function () {
    wx.navigateTo({
      url: '../xiangkan/xiangkan'
    })
  },
  kanguo: function () {
    wx.navigateTo({
      url: '../kanguo/kanguo'
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    const _this = this;
    wx.request({
      url: "https://douban.uieee.com/v2/movie/top250",
      data: {count:1},
      header: {
        'content-type': 'json'
      },
      success: function (res) {
        console.log(res.data.subjects)
        _this.setData({
          casts: res.data.subjects[0].casts
        })
      }
    })
    wx.request({
      url: "https://douban.uieee.com/v2/movie/top250",
      data: { count: 1 },
      header: {
        'content-type': 'json'
      },
      success: function (res) {
        console.log(res.data.subjects)
        _this.setData({
          directors: res.data.subjects[0].directors
        })
      }
    })
    wx.request({
      url: "https://douban.uieee.com/v2/movie/top250",
      data: { count: 1 },
      header: {
        'content-type': 'json'
      },
      success: function (res) {
        console.log(res.data.subjects)
        _this.setData({
          subjects: res.data.subjects
        })
      }
    })
      let _that = this; // 一定要先存this，避免在回调中设置data时报错

    setTimeout(function () {
      let query = wx.createSelectorQuery();
      query.select('.content').boundingClientRect();
      query.exec(function (rect) {
        if (rect[0] === null) {
          return
        } else if (rect[0].height > 300) { // 自定义一个边界高度
          _that.setData({
            isFold: true
          })
        }
      })
    }, 100)
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})