//index.js
//获取应用实例
const app = getApp()

Page({
  data: {
    subjects:[]
   },
  //事件处理函数
  ml: function() {
    wx.navigateTo({
      url: '../well_received/well_received'
    })
  },
  rem: function () {
    wx.navigateTo({
      url: '../doubanhot/doubanhot'
    })
  },
  jijiang: function () {
    wx.navigateTo({
      url: '../Upcoming release/Upcoming release'
    })
  },
  onLoad: function () {
    const _this = this;
    wx.request({
      url: "https://douban.uieee.com/v2/movie/in_theaters",
      data: {},
      header: {
        'content-type': 'json'
      },
      success: function (res) {
        console.log(res.data)
        _this.setData({
          subjects: res.data.subjects
        })
      }
    }),
      wx.request({
      url: "https://douban.uieee.com/v2/movie/top250",
        data: {},
        header: {
          'content-type': 'json'
        },
        success: function (res) {
          console.log(res.data)
          _this.setData({
            subjects_top250: res.data.subjects
          })
        }
      }),
      wx.request({
      url: "https://douban.uieee.com/v2/movie/coming_soon",
        data: {},
        header: {
          'content-type': 'json'
        },
        success: function (res) {
          console.log(res.data)
          _this.setData({
            subjects_going: res.data.subjects
          })
        }
      })
  },
  
  
})
